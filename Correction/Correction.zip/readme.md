replace old files with new one-
(a) files (png) -
	location:-assets/images
	1. candidpage-logo.png
	2. CL-Logo.png
	3. cpf-Logo.png

(b) one js file
	location:-assets/js
	file:- main.js

(c) Terms-Conditions.html
(d) Privacy-policy.html